/**
 * 
 */
/**
 * 
 */
module Gui {
	requires java.desktop;
}